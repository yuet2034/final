# Work & Worker Connector

A full-stack **MERN** (MongoDB, Express, React, Node.js) web application that connects:

1. **Job Seekers / Workers** — people looking for jobs
2. **Job Givers** — people who need workers
3. **Companies** — organizations that need workers

Users can register as a **Job Seeker**, **Job Giver**, **Both**, or a **Company**. Job Givers and
Companies post jobs, workers search and apply for them, and the system recommends the most
relevant workers for each job and notifies matching workers automatically when a new job is
posted.

---

## 1. What This Project Does

- Users register and log in securely (passwords hashed with **bcryptjs**, sessions handled with **JWT**).
- After logging in, users land on a **Dashboard** with two big options: **Find a Worker** and **Find a Job**.
- Job Givers/Companies can **post jobs**, **view applicants**, and **accept/reject** applications.
- Workers can **build a profile**, **search for jobs**, **apply to jobs**, and **track their applications**.
- Every job post automatically creates **notifications** for workers whose category or skills match.
- Each job page shows a simple list of **recommended workers** based on category, skills, location, price and rating.
- Workers can **promote their profile** (`isPromoted: true`) to appear higher in search results and recommendations — this is a simulated feature with no real payment integration (ready for a payment gateway to be added later).

---

## 2. Technologies Used

| Layer          | Technology                     |
|----------------|---------------------------------|
| Frontend       | React.js + Vite                 |
| Backend        | Node.js + Express.js            |
| Database       | MongoDB + Mongoose               |
| API            | REST API                        |
| Authentication | JWT (jsonwebtoken)               |
| Password Hash  | bcryptjs                        |
| Styling        | Plain, hand-written CSS          |

---

## 3. Project Structure

```
work-worker-connector/
├── client/                  # React frontend (Vite)
│   ├── src/
│   │   ├── components/      # Reusable UI pieces (Navbar, JobCard, etc.)
│   │   ├── pages/           # Route-level pages (Home, Login, Dashboard, etc.)
│   │   ├── services/        # Axios API instance
│   │   ├── context/         # AuthContext (login state, JWT persistence)
│   │   ├── App.jsx
│   │   ├── main.jsx
│   │   └── index.css
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
│
├── server/                  # Express backend
│   ├── config/db.js         # MongoDB connection
│   ├── controllers/         # Route logic
│   ├── models/              # Mongoose schemas
│   ├── routes/               # Express routers
│   ├── middleware/           # auth.js (JWT), error.js (error handling)
│   ├── utils/generateToken.js
│   ├── seed.js               # Optional demo data script
│   ├── server.js             # App entry point
│   └── package.json
│
├── .gitignore
├── package.json
└── README.md
```

---

## 4. Prerequisites

- **Node.js** v18 or higher
- **npm** (comes with Node.js)
- A **MongoDB** database — either:
  - A local MongoDB server (`mongodb://127.0.0.1:27017/work-worker-connector`), or
  - A free cloud database from [MongoDB Atlas](https://www.mongodb.com/atlas)

---

## 5. Installation & Setup

### Step 1 — Download / Extract the Project

Extract the ZIP file, then open a terminal inside the `work-worker-connector` folder.

### Step 2 — Configure the Backend Environment Variables

Inside the `server/` folder, copy `.env.example` to `.env`:

```bash
cd server
cp .env.example .env
```

Then open `.env` and fill in your own values:

```text
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/work-worker-connector
JWT_SECRET=your_super_secret_jwt_key_change_this
```

> If you use MongoDB Atlas, `MONGO_URI` will look like:
> `mongodb+srv://<username>:<password>@cluster0.mongodb.net/work-worker-connector`

Never commit your real `.env` file — it is already excluded via `.gitignore`.

### Step 3 — Install & Start the Backend

```bash
cd server
npm install
npm run dev
```

The API will start on **http://localhost:5000**. You should see:

```
MongoDB Connected: ...
Server running on port 5000
```

### Step 4 — (Optional) Load Demo Data

To quickly test the app with sample workers, jobs, applications and notifications:

```bash
cd server
npm run seed
```

This creates several demo users (all with password `password123`), a few jobs, one sample
application, and a couple of notifications.

### Step 5 — Configure & Start the Frontend

Open a **new terminal window**, then:

```bash
cd client
cp .env.example .env
npm install
npm run dev
```

The frontend will start on **http://localhost:5173** and will automatically talk to the backend
at `http://localhost:5000/api` (configured in `client/.env` via `VITE_API_URL`).

### Step 6 — Open the App

Visit **http://localhost:5173** in your browser.

---

## 6. Example Login / Registration Flow

1. Go to the Home page and click **Sign Up**.
2. Fill in your name, email, password (6+ characters), phone number, and choose an account type
   (Job Seeker, Job Giver, Both, or Company).
3. On success, you're logged in automatically and redirected to the **Dashboard**.
4. From the Dashboard, click **Find Workers** or **Find Jobs**, or use the top navigation to
   post a job, edit your profile, view applications, or check notifications.
5. Refreshing the page keeps you logged in — the JWT token is stored in `localStorage` and
   validated against `/api/auth/me` on load.
6. Click **Logout** in the navbar to end your session.

If you loaded the demo/seed data, you can log in with any of the seeded emails
(e.g. `abebe.worker@example.com`) and the password `password123`.

---

## 7. Database Models

### User
```text
name, email, password (hashed), phone, accountType,
location, skills[], experience, category, expectedPrice,
description, profileImage, rating, isPromoted, createdAt
```

### Job
```text
title, description, category, requiredSkills[], location,
price, duration, status, postedBy (ref: User), createdAt
```

### Application
```text
job (ref: Job), worker (ref: User), message, status, createdAt
```
A unique index on `(job, worker)` prevents a worker from applying to the same job twice.

### Notification
```text
user (ref: User), message, job (ref: Job), isRead, createdAt
```

---

## 8. REST API Endpoints

### Authentication
| Method | Endpoint             | Access  | Description                     |
|--------|-----------------------|---------|----------------------------------|
| POST   | /api/auth/register     | Public  | Register a new user             |
| POST   | /api/auth/login         | Public  | Log in and receive a JWT        |
| GET    | /api/auth/me            | Private | Get the logged-in user's data   |

### Users
| Method | Endpoint             | Access  | Description                          |
|--------|-----------------------|---------|----------------------------------------|
| GET    | /api/users              | Public  | List all users (public fields only)  |
| GET    | /api/users/workers       | Public  | Search/filter workers                |
| GET    | /api/users/:id           | Public  | Get a single user's public profile    |
| PUT    | /api/users/profile        | Private | Update your own profile              |
| PUT    | /api/users/promote         | Private | Simulate promoting your profile      |

### Jobs
| Method | Endpoint                          | Access  | Description                          |
|--------|-------------------------------------|---------|----------------------------------------|
| POST   | /api/jobs                            | Private | Create a job (also creates notifications) |
| GET    | /api/jobs                            | Public  | Search/filter jobs                    |
| GET    | /api/jobs/:id                        | Public  | Get one job                           |
| PUT    | /api/jobs/:id                        | Private | Update a job (owner only)             |
| DELETE | /api/jobs/:id                        | Private | Delete a job (owner only)             |
| GET    | /api/jobs/my/posted                  | Private | List jobs you posted                  |
| GET    | /api/jobs/:id/recommended-workers    | Public  | Get recommended workers for a job     |

### Applications
| Method | Endpoint                        | Access  | Description                             |
|--------|-----------------------------------|---------|--------------------------------------------|
| POST   | /api/applications                  | Private | Apply for a job                          |
| GET    | /api/applications/my                | Private | View your own applications               |
| GET    | /api/applications/job/:jobId        | Private | View applicants for your job (owner only) |
| PUT    | /api/applications/:id               | Private | Accept/Reject an application (owner only) |

### Notifications
| Method | Endpoint                       | Access  | Description                |
|--------|-----------------------------------|---------|------------------------------|
| GET    | /api/notifications                  | Private | Get your notifications      |
| PUT    | /api/notifications/:id/read         | Private | Mark a notification as read |

---

## 9. How the Worker Recommendation Works

For each job, the backend scores every worker using simple, easy-to-understand rules:

- +3 points if the worker's category matches the job's category
- +2 points for each matching skill
- +2 points if the worker's location matches the job's location
- +1 point if the worker's expected price is within the job's price
- + (rating × 0.5) points
- +5 points if the worker has promoted their profile (`isPromoted: true`)

Workers are sorted by score (highest first) and the top 10 are shown. Promoted workers get a
meaningful boost, so they tend to appear near the top.

---

## 10. Notes on Error Handling

- The backend uses a centralized Express error handler (`middleware/error.js`) that returns
  clear JSON error messages and proper HTTP status codes for validation errors, duplicate
  emails, invalid IDs, and unexpected server errors.
- If MongoDB fails to connect, the server logs the error and exits instead of running in a
  broken state.
- The frontend shows loading states, clear error messages, and empty states (e.g. "No jobs
  found") instead of crashing when an API call fails.

---

## 11. CORS

The backend is configured to accept requests only from the Vite dev server
(`http://localhost:5173`), so there are no CORS errors during local development. If you deploy
the frontend elsewhere, update the `origin` list in `server/server.js`.

---

## 12. Notes on the Promotion Feature

The **Promote My Profile** button (found on the Profile page) simply sets `isPromoted: true` on
the user's document — there is no real payment processing in this version. This keeps the
feature simple while making it easy to plug in a real payment gateway later without changing
any other part of the app.

---

## 13. Running Both Apps at Once (Optional)

You can also use the helper scripts in the root `package.json`:

```bash
npm run install-all   # installs both server and client dependencies
npm run server        # starts the backend
npm run client        # starts the frontend (run in a separate terminal)
```

---

Enjoy building on top of **Work & Worker Connector**!
