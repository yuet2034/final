import React from "react";
import { Link } from "react-router-dom";

// Used on the worker's "My Applications" page
const ApplicationCard = ({ application }) => {
  const job = application.job;

  return (
    <div className="card application-card">
      <div className="card-header">
        <h3>{job ? job.title : "Job no longer available"}</h3>
        <span className={`status-badge status-${application.status.toLowerCase()}`}>
          {application.status}
        </span>
      </div>
      {job && (
        <>
          <p className="card-meta">
            <strong>Category:</strong> {job.category} &nbsp;|&nbsp; <strong>Location:</strong>{" "}
            {job.location}
          </p>
          <p className="card-meta">
            <strong>Price:</strong> {job.price} ETB
          </p>
        </>
      )}
      {application.message && (
        <p className="card-description">
          <strong>Your message:</strong> {application.message}
        </p>
      )}
      <p className="card-date">
        Applied on: {new Date(application.createdAt).toLocaleDateString()}
      </p>
      {job && (
        <Link to={`/jobs/${job._id}`} className="btn btn-secondary">
          View Job
        </Link>
      )}
    </div>
  );
};

export default ApplicationCard;
