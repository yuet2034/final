import React from "react";

const Footer = () => {
  return (
    <footer className="footer">
      <p>&copy; {new Date().getFullYear()} Work &amp; Worker Connector. All rights reserved.</p>
    </footer>
  );
};

export default Footer;
