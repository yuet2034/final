import React from "react";
import { Link } from "react-router-dom";

const JobCard = ({ job }) => {
  return (
    <div className="card job-card">
      <div className="card-header">
        <h3>{job.title}</h3>
        <span className={`status-badge status-${job.status.replace(/\s+/g, "-").toLowerCase()}`}>
          {job.status}
        </span>
      </div>
      <p className="card-meta">
        <strong>Category:</strong> {job.category} &nbsp;|&nbsp; <strong>Location:</strong>{" "}
        {job.location}
      </p>
      <p className="card-meta">
        <strong>Price:</strong> {job.price} ETB
      </p>
      <p className="card-description">{job.description}</p>
      {job.requiredSkills && job.requiredSkills.length > 0 && (
        <p className="card-skills">
          <strong>Skills:</strong> {job.requiredSkills.join(", ")}
        </p>
      )}
      <p className="card-date">
        Posted: {new Date(job.createdAt).toLocaleDateString()}
      </p>
      <Link to={`/jobs/${job._id}`} className="btn btn-secondary">
        View Job
      </Link>
    </div>
  );
};

export default JobCard;
