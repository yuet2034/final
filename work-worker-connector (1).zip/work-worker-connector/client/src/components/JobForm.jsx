import React, { useState } from "react";

const CATEGORIES = [
  "Construction",
  "Cleaning",
  "Driving",
  "Plumbing",
  "Electrical",
  "Painting",
  "Gardening",
  "Cooking",
  "Security",
  "IT",
  "Other",
];

// Reusable form used by the CreateJob page (and could be reused for editing)
const JobForm = ({ initialData = {}, onSubmit, submitLabel = "Post Job" }) => {
  const [formData, setFormData] = useState({
    title: initialData.title || "",
    description: initialData.description || "",
    category: initialData.category || "",
    requiredSkills: initialData.requiredSkills ? initialData.requiredSkills.join(", ") : "",
    location: initialData.location || "",
    price: initialData.price || "",
    duration: initialData.duration || "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      price: Number(formData.price),
      requiredSkills: formData.requiredSkills
        ? formData.requiredSkills.split(",").map((s) => s.trim())
        : [],
    });
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
      <label>Job Title</label>
      <input
        type="text"
        name="title"
        value={formData.title}
        onChange={handleChange}
        placeholder="e.g. House Painting"
        required
      />

      <label>Description</label>
      <textarea
        name="description"
        value={formData.description}
        onChange={handleChange}
        placeholder="Describe the job in detail"
        rows="4"
        required
      />

      <label>Category</label>
      <select name="category" value={formData.category} onChange={handleChange} required>
        <option value="">Select a category</option>
        {CATEGORIES.map((cat) => (
          <option key={cat} value={cat}>
            {cat}
          </option>
        ))}
      </select>

      <label>Required Skills (comma separated)</label>
      <input
        type="text"
        name="requiredSkills"
        value={formData.requiredSkills}
        onChange={handleChange}
        placeholder="e.g. Wall painting, Interior painting"
      />

      <label>Location</label>
      <input
        type="text"
        name="location"
        value={formData.location}
        onChange={handleChange}
        placeholder="e.g. Addis Ababa"
        required
      />

      <label>Price (ETB)</label>
      <input
        type="number"
        name="price"
        value={formData.price}
        onChange={handleChange}
        placeholder="e.g. 5000"
        min="0"
        required
      />

      <label>Job Duration</label>
      <input
        type="text"
        name="duration"
        value={formData.duration}
        onChange={handleChange}
        placeholder="e.g. 3 days"
      />

      <button type="submit" className="btn btn-primary">
        {submitLabel}
      </button>
    </form>
  );
};

export default JobForm;
