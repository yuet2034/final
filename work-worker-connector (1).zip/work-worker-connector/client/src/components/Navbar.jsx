import React, { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  const closeMenu = () => setMenuOpen(false);

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <Link to="/" className="navbar-logo" onClick={closeMenu}>
          Work &amp; Worker Connector
        </Link>

        <button
          className="navbar-toggle"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          &#9776;
        </button>

        <div className={`navbar-links ${menuOpen ? "open" : ""}`}>
          {user ? (
            <>
              <Link to="/dashboard" onClick={closeMenu}>Dashboard</Link>
              <Link to="/find-workers" onClick={closeMenu}>Find Workers</Link>
              <Link to="/find-jobs" onClick={closeMenu}>Find Jobs</Link>
              <Link to="/my-jobs" onClick={closeMenu}>My Jobs</Link>
              <Link to="/applications" onClick={closeMenu}>Applications</Link>
              <Link to="/notifications" onClick={closeMenu}>Notifications</Link>
              <Link to="/profile" onClick={closeMenu}>Profile</Link>
              <button className="btn-link" onClick={() => { handleLogout(); closeMenu(); }}>
                Logout
              </button>
            </>
          ) : (
            <>
              <Link to="/find-jobs" onClick={closeMenu}>Find Jobs</Link>
              <Link to="/find-workers" onClick={closeMenu}>Find Workers</Link>
              <Link to="/login" onClick={closeMenu}>Login</Link>
              <Link to="/register" className="btn-nav-highlight" onClick={closeMenu}>
                Sign Up
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
