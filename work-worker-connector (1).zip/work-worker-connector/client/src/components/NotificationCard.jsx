import React from "react";
import { Link } from "react-router-dom";

const NotificationCard = ({ notification, onMarkRead }) => {
  return (
    <div className={`card notification-card ${notification.isRead ? "read" : "unread"}`}>
      <p className="card-description">{notification.message}</p>
      <p className="card-date">{new Date(notification.createdAt).toLocaleString()}</p>
      <div className="card-actions">
        {notification.job && (
          <Link to={`/jobs/${notification.job._id}`} className="btn btn-secondary">
            View Job
          </Link>
        )}
        {!notification.isRead && (
          <button className="btn btn-outline" onClick={() => onMarkRead(notification._id)}>
            Mark as Read
          </button>
        )}
      </div>
    </div>
  );
};

export default NotificationCard;
