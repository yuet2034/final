import React, { useState } from "react";

const CATEGORIES = [
  "",
  "Construction",
  "Cleaning",
  "Driving",
  "Plumbing",
  "Electrical",
  "Painting",
  "Gardening",
  "Cooking",
  "Security",
  "IT",
  "Other",
];

const ACCOUNT_TYPES = ["Job Seeker", "Job Giver", "Both", "Company"];

const ProfileForm = ({ initialData = {}, onSubmit }) => {
  const [formData, setFormData] = useState({
    name: initialData.name || "",
    phone: initialData.phone || "",
    accountType: initialData.accountType || "Job Seeker",
    location: initialData.location || "",
    skills: initialData.skills ? initialData.skills.join(", ") : "",
    experience: initialData.experience || "",
    category: initialData.category || "",
    expectedPrice: initialData.expectedPrice || "",
    description: initialData.description || "",
    profileImage: initialData.profileImage || "",
  });

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      expectedPrice: Number(formData.expectedPrice) || 0,
      skills: formData.skills ? formData.skills.split(",").map((s) => s.trim()) : [],
    });
  };

  return (
    <form className="form" onSubmit={handleSubmit}>
      <label>Full Name</label>
      <input type="text" name="name" value={formData.name} onChange={handleChange} required />

      <label>Phone</label>
      <input type="text" name="phone" value={formData.phone} onChange={handleChange} required />

      <label>Account Type</label>
      <select name="accountType" value={formData.accountType} onChange={handleChange}>
        {ACCOUNT_TYPES.map((type) => (
          <option key={type} value={type}>
            {type}
          </option>
        ))}
      </select>

      <label>Profile Photo URL</label>
      <input
        type="text"
        name="profileImage"
        value={formData.profileImage}
        onChange={handleChange}
        placeholder="https://example.com/photo.jpg"
      />

      <label>Location</label>
      <input
        type="text"
        name="location"
        value={formData.location}
        onChange={handleChange}
        placeholder="e.g. Addis Ababa"
      />

      <label>Job Category (for workers)</label>
      <select name="category" value={formData.category} onChange={handleChange}>
        {CATEGORIES.map((cat) => (
          <option key={cat} value={cat}>
            {cat === "" ? "Select a category" : cat}
          </option>
        ))}
      </select>

      <label>Skills (comma separated)</label>
      <input
        type="text"
        name="skills"
        value={formData.skills}
        onChange={handleChange}
        placeholder="e.g. Wall painting, Interior painting"
      />

      <label>Experience</label>
      <input
        type="text"
        name="experience"
        value={formData.experience}
        onChange={handleChange}
        placeholder="e.g. 5 years"
      />

      <label>Expected Price (ETB)</label>
      <input
        type="number"
        name="expectedPrice"
        value={formData.expectedPrice}
        onChange={handleChange}
        min="0"
      />

      <label>Short Description</label>
      <textarea
        name="description"
        value={formData.description}
        onChange={handleChange}
        rows="4"
        placeholder="Tell others about yourself or your work"
      />

      <button type="submit" className="btn btn-primary">
        Save Profile
      </button>
    </form>
  );
};

export default ProfileForm;
