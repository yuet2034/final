import React from "react";

const CATEGORIES = [
  "Construction",
  "Cleaning",
  "Driving",
  "Plumbing",
  "Electrical",
  "Painting",
  "Gardening",
  "Cooking",
  "Security",
  "IT",
  "Other",
];

// Reusable filter bar for both Find Jobs and Find Workers pages
const SearchBar = ({ filters, onChange, onSubmit }) => {
  const handleChange = (e) => {
    onChange({ ...filters, [e.target.name]: e.target.value });
  };

  return (
    <form className="search-bar" onSubmit={onSubmit}>
      <select name="category" value={filters.category} onChange={handleChange}>
        <option value="">All Categories</option>
        {CATEGORIES.map((cat) => (
          <option key={cat} value={cat}>
            {cat}
          </option>
        ))}
      </select>

      <input
        type="text"
        name="location"
        placeholder="Location"
        value={filters.location}
        onChange={handleChange}
      />

      <input
        type="text"
        name="skills"
        placeholder="Skills (comma separated)"
        value={filters.skills}
        onChange={handleChange}
      />

      <input
        type="number"
        name="maxPrice"
        placeholder="Max Price"
        value={filters.maxPrice}
        onChange={handleChange}
        min="0"
      />

      <button type="submit" className="btn btn-primary">
        Search
      </button>
    </form>
  );
};

export default SearchBar;
