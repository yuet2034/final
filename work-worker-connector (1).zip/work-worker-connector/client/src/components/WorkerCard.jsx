import React from "react";
import { Link } from "react-router-dom";

const WorkerCard = ({ worker }) => {
  return (
    <div className={`card worker-card ${worker.isPromoted ? "promoted" : ""}`}>
      {worker.isPromoted && <span className="promoted-badge">Promoted</span>}
      <img
        src={worker.profileImage || "https://via.placeholder.com/100?text=Worker"}
        alt={worker.name}
        className="worker-avatar"
      />
      <h3>{worker.name}</h3>
      {worker.category && <p className="card-meta"><strong>Category:</strong> {worker.category}</p>}
      {worker.skills && worker.skills.length > 0 && (
        <p className="card-meta"><strong>Skills:</strong> {worker.skills.join(", ")}</p>
      )}
      {worker.location && <p className="card-meta"><strong>Location:</strong> {worker.location}</p>}
      {worker.expectedPrice > 0 && (
        <p className="card-meta"><strong>Expected Price:</strong> {worker.expectedPrice} ETB</p>
      )}
      <p className="card-meta"><strong>Rating:</strong> {worker.rating ? worker.rating.toFixed(1) : "No rating yet"} / 5</p>
      <div className="card-actions">
        <Link to={`/workers/${worker._id}`} className="btn btn-secondary">
          View Profile
        </Link>
        {(worker.phone || worker.email) && (
          <a href={`tel:${worker.phone}`} className="btn btn-outline">
            Contact
          </a>
        )}
      </div>
    </div>
  );
};

export default WorkerCard;
