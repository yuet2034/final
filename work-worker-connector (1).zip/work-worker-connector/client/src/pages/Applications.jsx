import React, { useState, useEffect, useCallback } from "react";
import api, { getErrorMessage } from "../services/api";
import ApplicationCard from "../components/ApplicationCard";

const Applications = () => {
  const [applications, setApplications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchApplications = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/applications/my");
      setApplications(res.data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchApplications();
  }, [fetchApplications]);

  return (
    <div className="list-page">
      <h1>My Applications</h1>
      <p className="page-subtitle">Track the status of the jobs you've applied to.</p>

      {loading && <div className="page-loading">Loading your applications...</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {!loading && !error && applications.length === 0 && (
        <div className="empty-state">
          <p>You haven't applied to any jobs yet.</p>
        </div>
      )}

      <div className="card-grid">
        {applications.map((app) => (
          <ApplicationCard key={app._id} application={app} />
        ))}
      </div>
    </div>
  );
};

export default Applications;
