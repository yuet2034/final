import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import JobForm from "../components/JobForm";
import api, { getErrorMessage } from "../services/api";

const CreateJob = () => {
  const navigate = useNavigate();
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleCreate = async (jobData) => {
    setError("");
    setSuccess("");
    try {
      const res = await api.post("/jobs", jobData);
      setSuccess("Job posted successfully!");
      setTimeout(() => navigate(`/jobs/${res.data.job._id}`), 1000);
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  return (
    <div className="form-page">
      <h1>Post a Job</h1>
      <p className="page-subtitle">Fill in the details below to find the right worker.</p>
      {error && <div className="alert alert-error">{error}</div>}
      {success && <div className="alert alert-success">{success}</div>}
      <JobForm onSubmit={handleCreate} submitLabel="Post Job" />
    </div>
  );
};

export default CreateJob;
