import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

const Dashboard = () => {
  const { user } = useContext(AuthContext);

  return (
    <div className="dashboard-page">
      <h1>Welcome back, {user ? user.name : "there"}!</h1>
      <p className="dashboard-subtitle">What would you like to do today?</p>

      <div className="dashboard-slides">
        <div className="dashboard-slide slide-worker">
          <h2>Find a Worker</h2>
          <p>Find skilled and reliable workers for your job.</p>
          <Link to="/find-workers" className="btn btn-primary">
            Find Workers
          </Link>
        </div>

        <div className="dashboard-slide slide-job">
          <h2>Find a Job</h2>
          <p>Find jobs that match your skills and location.</p>
          <Link to="/find-jobs" className="btn btn-primary">
            Find Jobs
          </Link>
        </div>
      </div>

      <div className="dashboard-quick-links">
        <Link to="/create-job" className="btn btn-outline">
          + Post a New Job
        </Link>
        <Link to="/my-jobs" className="btn btn-outline">
          My Posted Jobs
        </Link>
        <Link to="/applications" className="btn btn-outline">
          My Applications
        </Link>
        <Link to="/profile" className="btn btn-outline">
          Edit Profile
        </Link>
      </div>
    </div>
  );
};

export default Dashboard;
