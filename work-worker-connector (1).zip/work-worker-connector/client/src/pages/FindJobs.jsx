import React, { useState, useEffect, useCallback } from "react";
import api, { getErrorMessage } from "../services/api";
import JobCard from "../components/JobCard";
import SearchBar from "../components/SearchBar";

const FindJobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filters, setFilters] = useState({
    category: "",
    location: "",
    skills: "",
    maxPrice: "",
  });

  const fetchJobs = useCallback(async (activeFilters) => {
    setLoading(true);
    setError("");
    try {
      const params = {};
      Object.entries(activeFilters).forEach(([key, value]) => {
        if (value) params[key] = value;
      });
      const res = await api.get("/jobs", { params });
      setJobs(res.data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchJobs(filters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchJobs(filters);
  };

  return (
    <div className="list-page">
      <h1>Find a Job</h1>
      <p className="page-subtitle">Find jobs that match your skills and location.</p>

      <SearchBar filters={filters} onChange={setFilters} onSubmit={handleSubmit} />

      {loading && <div className="page-loading">Loading jobs...</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {!loading && !error && jobs.length === 0 && (
        <div className="empty-state">
          <p>No jobs found. Try adjusting your search filters.</p>
        </div>
      )}

      <div className="card-grid">
        {jobs.map((job) => (
          <JobCard key={job._id} job={job} />
        ))}
      </div>
    </div>
  );
};

export default FindJobs;
