import React, { useState, useEffect, useCallback } from "react";
import api, { getErrorMessage } from "../services/api";
import WorkerCard from "../components/WorkerCard";
import SearchBar from "../components/SearchBar";

const FindWorkers = () => {
  const [workers, setWorkers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filters, setFilters] = useState({
    category: "",
    location: "",
    skills: "",
    maxPrice: "",
  });

  const fetchWorkers = useCallback(async (activeFilters) => {
    setLoading(true);
    setError("");
    try {
      const params = {};
      Object.entries(activeFilters).forEach(([key, value]) => {
        if (value) params[key] = value;
      });
      const res = await api.get("/users/workers", { params });
      setWorkers(res.data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchWorkers(filters);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleSubmit = (e) => {
    e.preventDefault();
    fetchWorkers(filters);
  };

  return (
    <div className="list-page">
      <h1>Find a Worker</h1>
      <p className="page-subtitle">Find skilled and reliable workers for your job.</p>

      <SearchBar filters={filters} onChange={setFilters} onSubmit={handleSubmit} />

      {loading && <div className="page-loading">Loading workers...</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {!loading && !error && workers.length === 0 && (
        <div className="empty-state">
          <p>No workers found. Try adjusting your search filters.</p>
        </div>
      )}

      <div className="card-grid">
        {workers.map((worker) => (
          <WorkerCard key={worker._id} worker={worker} />
        ))}
      </div>
    </div>
  );
};

export default FindWorkers;
