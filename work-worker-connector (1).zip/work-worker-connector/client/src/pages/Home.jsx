import React, { useContext } from "react";
import { Link } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

const Home = () => {
  const { user } = useContext(AuthContext);

  return (
    <div className="home-page">
      <section className="hero">
        <h1>Work &amp; Worker Connector</h1>
        <p className="hero-subtitle">
          The fastest and easiest way to connect people who need work done with
          skilled workers and companies ready to help. Whether you need a
          worker or you are looking for a job, we make it simple.
        </p>
        <div className="hero-buttons">
          <Link to="/find-workers" className="btn btn-primary">
            Find a Worker
          </Link>
          <Link to="/find-jobs" className="btn btn-secondary">
            Find a Job
          </Link>
          {!user && (
            <>
              <Link to="/login" className="btn btn-outline">
                Login
              </Link>
              <Link to="/register" className="btn btn-outline">
                Sign Up
              </Link>
            </>
          )}
        </div>
      </section>

      <section className="how-it-works">
        <h2>How It Works</h2>
        <div className="how-it-works-grid">
          <div className="how-card">
            <h3>1. Create an Account</h3>
            <p>Sign up as a Job Seeker, Job Giver, Both, or a Company in just a minute.</p>
          </div>
          <div className="how-card">
            <h3>2. Post or Search</h3>
            <p>Job Givers post jobs. Workers search and apply for jobs that match their skills.</p>
          </div>
          <div className="how-card">
            <h3>3. Connect &amp; Get Work Done</h3>
            <p>Review applicants or recommended workers, then contact and hire directly.</p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
