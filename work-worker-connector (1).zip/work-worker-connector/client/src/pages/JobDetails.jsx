import React, { useState, useEffect, useContext, useCallback } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import api, { getErrorMessage } from "../services/api";
import { AuthContext } from "../context/AuthContext";
import WorkerCard from "../components/WorkerCard";

const JobDetails = () => {
  const { id } = useParams();
  const { user } = useContext(AuthContext);
  const navigate = useNavigate();

  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const [recommended, setRecommended] = useState([]);
  const [applicants, setApplicants] = useState([]);
  const [applyMessage, setApplyMessage] = useState("");
  const [applyStatus, setApplyStatus] = useState("");
  const [applying, setApplying] = useState(false);

  const isOwner = user && job && job.postedBy && job.postedBy._id === user._id;
  const canApply =
    user &&
    job &&
    !isOwner &&
    (user.accountType === "Job Seeker" || user.accountType === "Both") &&
    job.status === "Open";

  const fetchJob = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await api.get(`/jobs/${id}`);
      setJob(res.data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, [id]);

  const fetchRecommended = useCallback(async () => {
    try {
      const res = await api.get(`/jobs/${id}/recommended-workers`);
      setRecommended(res.data);
    } catch (err) {
      // Non-critical - fail silently in UI, keep list empty
      setRecommended([]);
    }
  }, [id]);

  const fetchApplicants = useCallback(async () => {
    try {
      const res = await api.get(`/applications/job/${id}`);
      setApplicants(res.data);
    } catch (err) {
      setApplicants([]);
    }
  }, [id]);

  useEffect(() => {
    fetchJob();
    fetchRecommended();
  }, [fetchJob, fetchRecommended]);

  useEffect(() => {
    if (isOwner) {
      fetchApplicants();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOwner]);

  const handleApply = async (e) => {
    e.preventDefault();
    if (!user) {
      navigate("/login");
      return;
    }
    setApplying(true);
    setApplyStatus("");
    try {
      await api.post("/applications", { jobId: id, message: applyMessage });
      setApplyStatus("Application submitted successfully.");
      setApplyMessage("");
    } catch (err) {
      setApplyStatus(getErrorMessage(err));
    } finally {
      setApplying(false);
    }
  };

  const handleApplicationUpdate = async (applicationId, status) => {
    try {
      await api.put(`/applications/${applicationId}`, { status });
      fetchApplicants();
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  if (loading) return <div className="page-loading">Loading job...</div>;
  if (error) return <div className="alert alert-error">{error}</div>;
  if (!job) return <div className="empty-state">Job not found.</div>;

  return (
    <div className="details-page">
      <div className="details-header">
        <h1>{job.title}</h1>
        <span className={`status-badge status-${job.status.replace(/\s+/g, "-").toLowerCase()}`}>
          {job.status}
        </span>
      </div>

      <p className="card-meta">
        <strong>Category:</strong> {job.category} &nbsp;|&nbsp; <strong>Location:</strong>{" "}
        {job.location}
      </p>
      <p className="card-meta">
        <strong>Price:</strong> {job.price} ETB &nbsp;|&nbsp; <strong>Duration:</strong>{" "}
        {job.duration || "Not specified"}
      </p>
      {job.requiredSkills && job.requiredSkills.length > 0 && (
        <p className="card-meta">
          <strong>Required Skills:</strong> {job.requiredSkills.join(", ")}
        </p>
      )}
      <p className="card-description">{job.description}</p>
      <p className="card-date">Posted: {new Date(job.createdAt).toLocaleDateString()}</p>
      {job.postedBy && (
        <p className="card-meta">
          <strong>Posted by:</strong> {job.postedBy.name}
        </p>
      )}

      {canApply && (
        <div className="apply-box">
          <h3>Apply for this Job</h3>
          {applyStatus && <div className="alert alert-success">{applyStatus}</div>}
          <form className="form" onSubmit={handleApply}>
            <label>Message to Job Giver (optional)</label>
            <textarea
              value={applyMessage}
              onChange={(e) => setApplyMessage(e.target.value)}
              rows="3"
              placeholder="Introduce yourself and explain why you're a good fit"
            />
            <button type="submit" className="btn btn-primary" disabled={applying}>
              {applying ? "Submitting..." : "Apply Now"}
            </button>
          </form>
        </div>
      )}

      {!user && (
        <div className="alert alert-info">
          <Link to="/login">Login</Link> or <Link to="/register">Sign Up</Link> to apply for this job.
        </div>
      )}

      {isOwner && (
        <div className="applicants-box">
          <h3>Applicants ({applicants.length})</h3>
          {applicants.length === 0 && <p>No applications yet.</p>}
          {applicants.map((app) => (
            <div className="card applicant-card" key={app._id}>
              <div className="card-header">
                <h4>{app.worker ? app.worker.name : "Unknown Worker"}</h4>
                <span className={`status-badge status-${app.status.toLowerCase()}`}>
                  {app.status}
                </span>
              </div>
              {app.worker && (
                <>
                  <p className="card-meta">
                    <strong>Skills:</strong> {(app.worker.skills || []).join(", ") || "N/A"}
                  </p>
                  <p className="card-meta">
                    <strong>Experience:</strong> {app.worker.experience || "N/A"}
                  </p>
                  <p className="card-meta">
                    <strong>Location:</strong> {app.worker.location || "N/A"}
                  </p>
                  <p className="card-meta">
                    <strong>Expected Price:</strong> {app.worker.expectedPrice || "N/A"} ETB
                  </p>
                  <p className="card-meta">
                    <strong>Rating:</strong> {app.worker.rating || 0} / 5
                  </p>
                </>
              )}
              {app.message && (
                <p className="card-description">
                  <strong>Message:</strong> {app.message}
                </p>
              )}
              <div className="card-actions">
                {app.worker && (
                  <Link to={`/workers/${app.worker._id}`} className="btn btn-secondary">
                    View Profile
                  </Link>
                )}
                {app.worker && app.worker.phone && (
                  <a href={`tel:${app.worker.phone}`} className="btn btn-outline">
                    Contact Worker
                  </a>
                )}
                {app.status === "Pending" && (
                  <>
                    <button
                      className="btn btn-primary"
                      onClick={() => handleApplicationUpdate(app._id, "Accepted")}
                    >
                      Accept
                    </button>
                    <button
                      className="btn btn-danger"
                      onClick={() => handleApplicationUpdate(app._id, "Rejected")}
                    >
                      Reject
                    </button>
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="recommended-box">
        <h3>Recommended Workers</h3>
        {recommended.length === 0 ? (
          <p>No matching workers found yet.</p>
        ) : (
          <div className="card-grid">
            {recommended.map((worker) => (
              <WorkerCard key={worker._id} worker={worker} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default JobDetails;
