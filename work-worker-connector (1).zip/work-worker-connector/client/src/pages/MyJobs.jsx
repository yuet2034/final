import React, { useState, useEffect, useCallback } from "react";
import { Link } from "react-router-dom";
import api, { getErrorMessage } from "../services/api";
import JobCard from "../components/JobCard";

const MyJobs = () => {
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchMyJobs = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/jobs/my/posted");
      setJobs(res.data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchMyJobs();
  }, [fetchMyJobs]);

  return (
    <div className="list-page">
      <div className="list-page-header">
        <h1>My Posted Jobs</h1>
        <Link to="/create-job" className="btn btn-primary">
          + Post a New Job
        </Link>
      </div>

      {loading && <div className="page-loading">Loading your jobs...</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {!loading && !error && jobs.length === 0 && (
        <div className="empty-state">
          <p>You haven't posted any jobs yet.</p>
          <Link to="/create-job" className="btn btn-primary">
            Post Your First Job
          </Link>
        </div>
      )}

      <div className="card-grid">
        {jobs.map((job) => (
          <JobCard key={job._id} job={job} />
        ))}
      </div>
    </div>
  );
};

export default MyJobs;
