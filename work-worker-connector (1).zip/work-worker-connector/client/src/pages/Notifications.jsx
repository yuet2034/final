import React, { useState, useEffect, useCallback } from "react";
import api, { getErrorMessage } from "../services/api";
import NotificationCard from "../components/NotificationCard";

const Notifications = () => {
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const fetchNotifications = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const res = await api.get("/notifications");
      setNotifications(res.data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchNotifications();
  }, [fetchNotifications]);

  const handleMarkRead = async (id) => {
    try {
      await api.put(`/notifications/${id}/read`);
      setNotifications((prev) =>
        prev.map((n) => (n._id === id ? { ...n, isRead: true } : n))
      );
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  return (
    <div className="list-page">
      <h1>Notifications</h1>
      <p className="page-subtitle">Stay updated on new jobs that match your skills.</p>

      {loading && <div className="page-loading">Loading notifications...</div>}
      {error && <div className="alert alert-error">{error}</div>}

      {!loading && !error && notifications.length === 0 && (
        <div className="empty-state">
          <p>You have no notifications yet.</p>
        </div>
      )}

      <div className="notification-list">
        {notifications.map((n) => (
          <NotificationCard key={n._id} notification={n} onMarkRead={handleMarkRead} />
        ))}
      </div>
    </div>
  );
};

export default Notifications;
