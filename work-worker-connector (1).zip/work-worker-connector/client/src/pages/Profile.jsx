import React, { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import ProfileForm from "../components/ProfileForm";
import api, { getErrorMessage } from "../services/api";

const Profile = () => {
  const { user, updateUserInContext } = useContext(AuthContext);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [promoting, setPromoting] = useState(false);

  const handleSave = async (formData) => {
    setError("");
    setMessage("");
    try {
      const res = await api.put("/users/profile", formData);
      updateUserInContext(res.data.user);
      setMessage("Profile updated successfully.");
    } catch (err) {
      setError(getErrorMessage(err));
    }
  };

  const handlePromote = async () => {
    setError("");
    setMessage("");
    setPromoting(true);
    try {
      const res = await api.put("/users/promote");
      updateUserInContext({ isPromoted: res.data.isPromoted });
      setMessage("Your profile has been promoted! You will now appear higher in search results.");
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setPromoting(false);
    }
  };

  if (!user) {
    return <div className="page-loading">Loading profile...</div>;
  }

  return (
    <div className="profile-page">
      <h1>My Profile</h1>
      {message && <div className="alert alert-success">{message}</div>}
      {error && <div className="alert alert-error">{error}</div>}

      <div className="profile-layout">
        <div className="profile-form-container">
          <ProfileForm initialData={user} onSubmit={handleSave} />
        </div>

        <div className="promote-box">
          <h3>Promote My Profile</h3>
          <p>
            Boost your visibility so more job givers find you first in worker
            recommendations and search results.
          </p>
          <p>
            Status:{" "}
            <strong>{user.isPromoted ? "Promoted" : "Not Promoted"}</strong>
          </p>
          {!user.isPromoted && (
            <button className="btn btn-primary" onClick={handlePromote} disabled={promoting}>
              {promoting ? "Promoting..." : "Promote My Profile"}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;
