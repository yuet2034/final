import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import api, { getErrorMessage } from "../services/api";

const WorkerDetails = () => {
  const { id } = useParams();
  const [worker, setWorker] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const fetchWorker = async () => {
      setLoading(true);
      setError("");
      try {
        const res = await api.get(`/users/${id}`);
        setWorker(res.data);
      } catch (err) {
        setError(getErrorMessage(err));
      } finally {
        setLoading(false);
      }
    };
    fetchWorker();
  }, [id]);

  if (loading) return <div className="page-loading">Loading profile...</div>;
  if (error) return <div className="alert alert-error">{error}</div>;
  if (!worker) return <div className="empty-state">Worker not found.</div>;

  return (
    <div className="details-page">
      <div className="worker-profile-header">
        <img
          src={worker.profileImage || "https://via.placeholder.com/120?text=Worker"}
          alt={worker.name}
          className="worker-avatar-large"
        />
        <div>
          <h1>
            {worker.name} {worker.isPromoted && <span className="promoted-badge">Promoted</span>}
          </h1>
          <p className="card-meta">{worker.accountType}</p>
        </div>
      </div>

      {worker.category && (
        <p className="card-meta">
          <strong>Category:</strong> {worker.category}
        </p>
      )}
      {worker.skills && worker.skills.length > 0 && (
        <p className="card-meta">
          <strong>Skills:</strong> {worker.skills.join(", ")}
        </p>
      )}
      {worker.location && (
        <p className="card-meta">
          <strong>Location:</strong> {worker.location}
        </p>
      )}
      {worker.experience && (
        <p className="card-meta">
          <strong>Experience:</strong> {worker.experience}
        </p>
      )}
      {worker.expectedPrice > 0 && (
        <p className="card-meta">
          <strong>Expected Price:</strong> {worker.expectedPrice} ETB
        </p>
      )}
      <p className="card-meta">
        <strong>Rating:</strong> {worker.rating ? worker.rating.toFixed(1) : "No rating yet"} / 5
      </p>
      {worker.description && <p className="card-description">{worker.description}</p>}

      <div className="card-actions">
        {worker.phone && (
          <a href={`tel:${worker.phone}`} className="btn btn-primary">
            Call {worker.phone}
          </a>
        )}
        {worker.email && (
          <a href={`mailto:${worker.email}`} className="btn btn-outline">
            Email {worker.email}
          </a>
        )}
      </div>
    </div>
  );
};

export default WorkerDetails;
