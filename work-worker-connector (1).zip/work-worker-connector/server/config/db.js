const mongoose = require("mongoose");

// Connect to MongoDB using the connection string from .env
const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGO_URI);
    console.log(`MongoDB Connected: ${conn.connection.host}`);
  } catch (error) {
    console.error(`MongoDB Connection Error: ${error.message}`);
    // Stop the server if the database cannot connect
    process.exit(1);
  }
};

module.exports = connectDB;
