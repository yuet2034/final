const Application = require("../models/Application");
const Job = require("../models/Job");

// @route   POST /api/applications
// @access  Private
const applyForJob = async (req, res, next) => {
  try {
    const { jobId, message } = req.body;

    if (!jobId) {
      return res.status(400).json({ message: "Job id is required" });
    }

    const job = await Job.findById(jobId);
    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    if (job.status !== "Open") {
      return res.status(400).json({ message: "This job is not open for applications" });
    }

    if (job.postedBy.toString() === req.user._id.toString()) {
      return res.status(400).json({ message: "You cannot apply to your own job" });
    }

    // Check for an existing application by this worker for this job
    const existingApplication = await Application.findOne({
      job: jobId,
      worker: req.user._id,
    });

    if (existingApplication) {
      return res.status(400).json({ message: "You have already applied to this job" });
    }

    const application = await Application.create({
      job: jobId,
      worker: req.user._id,
      message: message || "",
    });

    res.status(201).json({
      message: "Application submitted successfully.",
      application,
    });
  } catch (error) {
    // Handles the unique index race condition (duplicate application)
    if (error.code === 11000) {
      return res.status(400).json({ message: "You have already applied to this job" });
    }
    next(error);
  }
};

// @route   GET /api/applications/my
// @access  Private
const getMyApplications = async (req, res, next) => {
  try {
    const applications = await Application.find({ worker: req.user._id })
      .populate("job")
      .sort({ createdAt: -1 });

    res.status(200).json(applications);
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/applications/job/:jobId
// @access  Private (only the job's owner)
const getApplicationsForJob = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.jobId);

    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    if (job.postedBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to view these applications" });
    }

    const applications = await Application.find({ job: req.params.jobId })
      .populate(
        "worker",
        "name email phone skills experience location expectedPrice rating profileImage"
      )
      .sort({ createdAt: -1 });

    res.status(200).json(applications);
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/applications/:id
// @access  Private (only the job's owner can accept/reject)
const updateApplicationStatus = async (req, res, next) => {
  try {
    const { status } = req.body;

    if (!["Pending", "Accepted", "Rejected"].includes(status)) {
      return res.status(400).json({ message: "Invalid application status" });
    }

    const application = await Application.findById(req.params.id).populate("job");

    if (!application) {
      return res.status(404).json({ message: "Application not found" });
    }

    if (application.job.postedBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to update this application" });
    }

    application.status = status;
    await application.save();

    res.status(200).json({ message: "Application status updated", application });
  } catch (error) {
    next(error);
  }
};

module.exports = {
  applyForJob,
  getMyApplications,
  getApplicationsForJob,
  updateApplicationStatus,
};
