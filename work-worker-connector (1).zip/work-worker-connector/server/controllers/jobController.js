const Job = require("../models/Job");
const User = require("../models/User");
const Notification = require("../models/Notification");

// @route   POST /api/jobs
// @access  Private (Job Giver, Both, Company)
const createJob = async (req, res, next) => {
  try {
    const { title, description, category, requiredSkills, location, price, duration } =
      req.body;

    if (!title || !description || !category || !location || !price) {
      return res.status(400).json({ message: "Please fill in all required job fields" });
    }

    const skillsArray = Array.isArray(requiredSkills)
      ? requiredSkills
      : typeof requiredSkills === "string" && requiredSkills.length > 0
      ? requiredSkills.split(",").map((s) => s.trim())
      : [];

    const job = await Job.create({
      title,
      description,
      category,
      requiredSkills: skillsArray,
      location,
      price,
      duration,
      postedBy: req.user._id,
    });

    // Find workers whose category or skills match this job, then notify them
    try {
      const matchingWorkers = await User.find({
        accountType: { $in: ["Job Seeker", "Both"] },
        $or: [
          { category: category },
          { skills: { $in: skillsArray.map((s) => new RegExp(s, "i")) } },
        ],
      }).select("_id");

      if (matchingWorkers.length > 0) {
        const notifications = matchingWorkers.map((worker) => ({
          user: worker._id,
          message: `New job available: ${title} in ${location}.`,
          job: job._id,
        }));
        await Notification.insertMany(notifications);
      }
    } catch (notifyError) {
      // Do not fail job creation if notifications fail
      console.error("Notification creation error:", notifyError.message);
    }

    res.status(201).json({ message: "Job posted successfully", job });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/jobs
// @access  Public
// Supports search/filter query params: category, location, skills, maxPrice, status
const getJobs = async (req, res, next) => {
  try {
    const { category, location, skills, maxPrice, status } = req.query;

    const query = {};

    if (category) query.category = category;
    if (status) query.status = status;
    if (location) query.location = { $regex: location, $options: "i" };
    if (maxPrice) query.price = { $lte: Number(maxPrice) };
    if (skills) {
      const skillList = skills.split(",").map((s) => s.trim());
      query.requiredSkills = { $in: skillList.map((s) => new RegExp(s, "i")) };
    }

    const jobs = await Job.find(query)
      .populate("postedBy", "name email phone accountType")
      .sort({ createdAt: -1 });

    res.status(200).json(jobs);
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/jobs/:id
// @access  Public
const getJobById = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id).populate(
      "postedBy",
      "name email phone accountType"
    );

    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    res.status(200).json(job);
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/jobs/:id
// @access  Private (only the job's owner)
const updateJob = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id);

    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    if (job.postedBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to edit this job" });
    }

    const editableFields = [
      "title",
      "description",
      "category",
      "requiredSkills",
      "location",
      "price",
      "duration",
      "status",
    ];

    editableFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        job[field] = req.body[field];
      }
    });

    const updatedJob = await job.save();

    res.status(200).json({ message: "Job updated successfully", job: updatedJob });
  } catch (error) {
    next(error);
  }
};

// @route   DELETE /api/jobs/:id
// @access  Private (only the job's owner)
const deleteJob = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id);

    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    if (job.postedBy.toString() !== req.user._id.toString()) {
      return res.status(403).json({ message: "Not authorized to delete this job" });
    }

    await job.deleteOne();

    res.status(200).json({ message: "Job deleted successfully" });
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/jobs/my/posted
// @access  Private
const getMyJobs = async (req, res, next) => {
  try {
    const jobs = await Job.find({ postedBy: req.user._id }).sort({ createdAt: -1 });
    res.status(200).json(jobs);
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/jobs/:id/recommended-workers
// @access  Public
// Simple recommendation: score workers by matching category, skills, location and rating
const getRecommendedWorkers = async (req, res, next) => {
  try {
    const job = await Job.findById(req.params.id);

    if (!job) {
      return res.status(404).json({ message: "Job not found" });
    }

    const candidates = await User.find({
      accountType: { $in: ["Job Seeker", "Both"] },
    }).select(
      "name profileImage category skills location expectedPrice rating isPromoted"
    );

    const scored = candidates.map((worker) => {
      let score = 0;

      if (worker.category && worker.category === job.category) score += 3;

      const workerSkills = (worker.skills || []).map((s) => s.toLowerCase());
      const jobSkills = (job.requiredSkills || []).map((s) => s.toLowerCase());
      const matchingSkills = workerSkills.filter((s) => jobSkills.includes(s));
      score += matchingSkills.length * 2;

      if (worker.location && job.location && worker.location.toLowerCase() === job.location.toLowerCase()) {
        score += 2;
      }

      if (worker.expectedPrice && job.price && worker.expectedPrice <= job.price) {
        score += 1;
      }

      score += (worker.rating || 0) * 0.5;

      // Promoted workers get a boost so they appear higher
      if (worker.isPromoted) score += 5;

      return { worker, score };
    });

    // Only show workers with at least some relevance
    const recommended = scored
      .filter((entry) => entry.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
      .map((entry) => entry.worker);

    res.status(200).json(recommended);
  } catch (error) {
    next(error);
  }
};

module.exports = {
  createJob,
  getJobs,
  getJobById,
  updateJob,
  deleteJob,
  getMyJobs,
  getRecommendedWorkers,
};
