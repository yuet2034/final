const User = require("../models/User");

// Fields that are safe to send to the frontend (never the password)
const PUBLIC_FIELDS =
  "name email phone accountType location skills experience category expectedPrice description profileImage rating isPromoted createdAt";

// @route   GET /api/users
// @access  Public
const getUsers = async (req, res, next) => {
  try {
    const users = await User.find().select(PUBLIC_FIELDS);
    res.status(200).json(users);
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/users/workers
// @access  Public
// Returns job seekers/workers, with optional search & filter query params:
// category, location, skills, maxPrice
const getWorkers = async (req, res, next) => {
  try {
    const { category, location, skills, maxPrice } = req.query;

    const query = {
      accountType: { $in: ["Job Seeker", "Both"] },
    };

    if (category) {
      query.category = category;
    }

    if (location) {
      query.location = { $regex: location, $options: "i" };
    }

    if (skills) {
      // skills query can be comma separated
      const skillList = skills.split(",").map((s) => s.trim());
      query.skills = { $in: skillList.map((s) => new RegExp(s, "i")) };
    }

    if (maxPrice) {
      query.expectedPrice = { $lte: Number(maxPrice) };
    }

    // Promoted workers appear first, then sorted by rating
    const workers = await User.find(query)
      .select(PUBLIC_FIELDS)
      .sort({ isPromoted: -1, rating: -1, createdAt: -1 });

    res.status(200).json(workers);
  } catch (error) {
    next(error);
  }
};

// @route   GET /api/users/:id
// @access  Public
const getUserById = async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id).select(PUBLIC_FIELDS);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json(user);
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/users/profile
// @access  Private
const updateProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    const editableFields = [
      "name",
      "phone",
      "location",
      "skills",
      "experience",
      "category",
      "expectedPrice",
      "description",
      "profileImage",
      "accountType",
    ];

    editableFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        user[field] = req.body[field];
      }
    });

    const updatedUser = await user.save();

    res.status(200).json({
      message: "Profile updated successfully",
      user: {
        _id: updatedUser._id,
        name: updatedUser.name,
        email: updatedUser.email,
        phone: updatedUser.phone,
        accountType: updatedUser.accountType,
        location: updatedUser.location,
        skills: updatedUser.skills,
        experience: updatedUser.experience,
        category: updatedUser.category,
        expectedPrice: updatedUser.expectedPrice,
        description: updatedUser.description,
        profileImage: updatedUser.profileImage,
        rating: updatedUser.rating,
        isPromoted: updatedUser.isPromoted,
      },
    });
  } catch (error) {
    next(error);
  }
};

// @route   PUT /api/users/promote
// @access  Private
// Simulated promotion - no real payment gateway is used
const promoteProfile = async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    user.isPromoted = true;
    await user.save();

    res.status(200).json({ message: "Your profile has been promoted!", isPromoted: true });
  } catch (error) {
    next(error);
  }
};

module.exports = { getUsers, getWorkers, getUserById, updateProfile, promoteProfile };
