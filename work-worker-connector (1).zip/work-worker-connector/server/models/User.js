const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Full name is required"],
      trim: true,
    },
    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      lowercase: true,
      trim: true,
      match: [/^\S+@\S+\.\S+$/, "Please enter a valid email address"],
    },
    password: {
      type: String,
      required: [true, "Password is required"],
      minlength: [6, "Password must be at least 6 characters"],
      select: false, // never return password by default
    },
    phone: {
      type: String,
      required: [true, "Phone number is required"],
      trim: true,
    },
    accountType: {
      type: String,
      enum: ["Job Seeker", "Job Giver", "Both", "Company"],
      required: [true, "Account type is required"],
    },
    location: {
      type: String,
      default: "",
    },
    skills: {
      type: [String],
      default: [],
    },
    experience: {
      type: String,
      default: "",
    },
    category: {
      type: String,
      enum: [
        "Construction",
        "Cleaning",
        "Driving",
        "Plumbing",
        "Electrical",
        "Painting",
        "Gardening",
        "Cooking",
        "Security",
        "IT",
        "Other",
        "",
      ],
      default: "",
    },
    expectedPrice: {
      type: Number,
      default: 0,
    },
    description: {
      type: String,
      default: "",
    },
    profileImage: {
      type: String,
      default: "",
    },
    rating: {
      type: Number,
      default: 0,
      min: 0,
      max: 5,
    },
    isPromoted: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true } // adds createdAt and updatedAt automatically
);

module.exports = mongoose.model("User", userSchema);
