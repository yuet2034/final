const express = require("express");
const router = express.Router();
const {
  createJob,
  getJobs,
  getJobById,
  updateJob,
  deleteJob,
  getMyJobs,
  getRecommendedWorkers,
} = require("../controllers/jobController");
const { protect } = require("../middleware/auth");

// Specific routes before /:id
router.get("/my/posted", protect, getMyJobs);

router.route("/").post(protect, createJob).get(getJobs);

router.get("/:id/recommended-workers", getRecommendedWorkers);

router
  .route("/:id")
  .get(getJobById)
  .put(protect, updateJob)
  .delete(protect, deleteJob);

module.exports = router;
