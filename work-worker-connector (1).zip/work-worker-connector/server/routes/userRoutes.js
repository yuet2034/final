const express = require("express");
const router = express.Router();
const {
  getUsers,
  getWorkers,
  getUserById,
  updateProfile,
  promoteProfile,
} = require("../controllers/userController");
const { protect } = require("../middleware/auth");

// NOTE: specific routes must come before the /:id route
router.get("/workers", getWorkers);
router.put("/profile", protect, updateProfile);
router.put("/promote", protect, promoteProfile);
router.get("/", getUsers);
router.get("/:id", getUserById);

module.exports = router;
