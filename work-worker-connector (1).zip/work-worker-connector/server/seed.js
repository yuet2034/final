// Optional script to insert example data into MongoDB for quick testing.
// Run with: npm run seed  (from inside the /server folder)
require("dotenv").config();
const bcrypt = require("bcryptjs");
const connectDB = require("./config/db");
const User = require("./models/User");
const Job = require("./models/Job");
const Application = require("./models/Application");
const Notification = require("./models/Notification");

const seedData = async () => {
  try {
    await connectDB();

    // Clear old demo data
    await User.deleteMany();
    await Job.deleteMany();
    await Application.deleteMany();
    await Notification.deleteMany();

    const hashedPassword = await bcrypt.hash("password123", 10);

    // ---- Sample Users ----
    const workers = await User.insertMany([
      {
        name: "Abebe Kebede",
        email: "abebe.worker@example.com",
        password: hashedPassword,
        phone: "0911111111",
        accountType: "Job Seeker",
        location: "Addis Ababa",
        skills: ["Wall painting", "Interior painting"],
        experience: "5 years",
        category: "Painting",
        expectedPrice: 4500,
        description: "Experienced house painter with attention to detail.",
        profileImage: "",
        rating: 4.5,
        isPromoted: true,
      },
      {
        name: "Sara Tesfaye",
        email: "sara.worker@example.com",
        password: hashedPassword,
        phone: "0922222222",
        accountType: "Job Seeker",
        location: "Addis Ababa",
        skills: ["Deep cleaning", "Laundry"],
        experience: "3 years",
        category: "Cleaning",
        expectedPrice: 1500,
        description: "Reliable and thorough home cleaner.",
        profileImage: "",
        rating: 4.2,
        isPromoted: false,
      },
      {
        name: "Dawit Mekonnen",
        email: "dawit.worker@example.com",
        password: hashedPassword,
        phone: "0933333333",
        accountType: "Both",
        location: "Bahir Dar",
        skills: ["Pipe fitting", "Leak repair"],
        experience: "7 years",
        category: "Plumbing",
        expectedPrice: 3000,
        description: "Licensed plumber for home and office jobs.",
        profileImage: "",
        rating: 4.8,
        isPromoted: false,
      },
      {
        name: "Helen Girma",
        email: "helen.worker@example.com",
        password: hashedPassword,
        phone: "0944444444",
        accountType: "Job Seeker",
        location: "Addis Ababa",
        skills: ["Wiring", "Circuit repair"],
        experience: "4 years",
        category: "Electrical",
        expectedPrice: 3500,
        description: "Certified electrician, safety-focused.",
        profileImage: "",
        rating: 4.0,
        isPromoted: false,
      },
    ]);

    const jobGiver = await User.create({
      name: "Yonas Alemu",
      email: "yonas.giver@example.com",
      password: hashedPassword,
      phone: "0955555555",
      accountType: "Job Giver",
      location: "Addis Ababa",
    });

    const company = await User.create({
      name: "Bright Homes PLC",
      email: "brighthomes@example.com",
      password: hashedPassword,
      phone: "0966666666",
      accountType: "Company",
      location: "Addis Ababa",
    });

    // ---- Sample Jobs ----
    const jobs = await Job.insertMany([
      {
        title: "House Painting",
        description: "Need a skilled painter for a 3-bedroom house, interior and exterior.",
        category: "Painting",
        requiredSkills: ["Wall painting", "Interior painting"],
        location: "Addis Ababa",
        price: 5000,
        duration: "3 days",
        status: "Open",
        postedBy: jobGiver._id,
      },
      {
        title: "Deep Cleaning Service",
        description: "Looking for a cleaner for a full apartment deep clean before moving in.",
        category: "Cleaning",
        requiredSkills: ["Deep cleaning"],
        location: "Addis Ababa",
        price: 1800,
        duration: "1 day",
        status: "Open",
        postedBy: company._id,
      },
      {
        title: "Fix Kitchen Sink Leak",
        description: "Kitchen sink is leaking and needs urgent repair.",
        category: "Plumbing",
        requiredSkills: ["Leak repair"],
        location: "Bahir Dar",
        price: 1200,
        duration: "Half day",
        status: "Open",
        postedBy: jobGiver._id,
      },
    ]);

    // ---- Sample Application ----
    await Application.create({
      job: jobs[0]._id,
      worker: workers[0]._id,
      message: "I have painted many houses in Addis Ababa. I can start immediately.",
      status: "Pending",
    });

    // ---- Sample Notifications ----
    await Notification.insertMany([
      {
        user: workers[0]._id,
        message: `New job available: ${jobs[0].title} in ${jobs[0].location}.`,
        job: jobs[0]._id,
      },
      {
        user: workers[1]._id,
        message: `New job available: ${jobs[1].title} in ${jobs[1].location}.`,
        job: jobs[1]._id,
      },
    ]);

    console.log("Seed data inserted successfully!");
    console.log("Demo login (any seeded user): password123");
    process.exit();
  } catch (error) {
    console.error("Seeding error:", error.message);
    process.exit(1);
  }
};

seedData();
